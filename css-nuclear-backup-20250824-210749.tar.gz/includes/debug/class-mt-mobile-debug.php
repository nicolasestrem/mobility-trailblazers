<?php
/**
 * Mobile Debug Helper
 * 
 * Temporary debugging class to troubleshoot mobile styles loading
 * 
 * @package MobilityTrailblazers
 * @since 4.1.0
 */

namespace MobilityTrailblazers\Debug;

if (!defined('ABSPATH')) {
    exit;
}

class MT_Mobile_Debug {
    
    /**
     * Initialize debug hooks
     */
    public static function init() {
        // Add debug info to admin bar
        add_action('admin_bar_menu', [__CLASS__, 'add_debug_menu'], 999);
        
        // Add debug comment to HTML
        add_action('wp_head', [__CLASS__, 'add_debug_comment'], 1);
        
        // Log style loading
        add_action('wp_enqueue_scripts', [__CLASS__, 'log_style_loading'], 999);
    }
    
    /**
     * Add debug menu to admin bar
     */
    public static function add_debug_menu($wp_admin_bar) {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $debug_info = self::get_debug_info();
        
        $wp_admin_bar->add_node([
            'id' => 'mt-mobile-debug',
            'title' => 'MT Mobile Debug',
            'href' => '#',
            'meta' => [
                'title' => 'Mobile Styles Debug Info'
            ]
        ]);
        
        foreach ($debug_info as $key => $value) {
            $wp_admin_bar->add_node([
                'id' => 'mt-mobile-debug-' . $key,
                'parent' => 'mt-mobile-debug',
                'title' => $key . ': ' . $value,
            ]);
        }
    }
    
    /**
     * Add debug comment to HTML
     */
    public static function add_debug_comment() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $debug_info = self::get_debug_info();
        echo "\n<!-- MT Mobile Debug -->\n";
        foreach ($debug_info as $key => $value) {
            echo "<!-- {$key}: {$value} -->\n";
        }
        echo "<!-- /MT Mobile Debug -->\n";
    }
    
    /**
     * Log style loading
     */
    public static function log_style_loading() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        global $wp_styles;
        $mobile_styles = [];
        
        foreach ($wp_styles->registered as $handle => $style) {
            if (strpos($handle, 'mobile') !== false || strpos($handle, 'mt-v4') !== false) {
                $mobile_styles[$handle] = [
                    'src' => $style->src,
                    'enqueued' => in_array($handle, $wp_styles->queue)
                ];
            }
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('MT Mobile Styles Debug: ' . print_r($mobile_styles, true));
        }
    }
    
    /**
     * Get debug information
     */
    private static function get_debug_info() {
        global $post;
        
        $info = [
            'Page_ID' => is_object($post) ? $post->ID : 'N/A',
            'Is_Front' => is_front_page() ? 'Yes' : 'No',
            'Is_Page_4996' => is_page(4996) ? 'Yes' : 'No',
            'Has_Shortcode' => (is_object($post) && has_shortcode($post->post_content, 'mt_jury_dashboard')) ? 'Yes' : 'No',
            'V4_Enabled' => 'Yes (Always)',
            'Mobile_Class' => class_exists('MobilityTrailblazers\Public\MT_Mobile_Styles') ? 'Exists' : 'Missing',
            'Assets_Class' => class_exists('MobilityTrailblazers\Public\MT_Public_Assets') ? 'Exists' : 'Missing',
        ];
        
        // Check if styles are enqueued
        if (function_exists('wp_style_is')) {
            $info['Mobile_CSS'] = wp_style_is('mt-v4-mobile-jury', 'enqueued') ? 'Enqueued' : 'Not Enqueued';
            $info['Mobile_JS'] = wp_script_is('mt-mobile-jury', 'enqueued') ? 'Enqueued' : 'Not Enqueued';
        }
        
        return $info;
    }
}