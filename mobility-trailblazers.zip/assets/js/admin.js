/**
 * Mobility Trailblazers Admin JavaScript
 */
// Mobile touch support for evaluation sliders
if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
    jQuery(document).ready(function($) {
        // Use event manager for proper cleanup
        if (window.MTEventManager) {
            MTEventManager.on('touchstart', '.mt-evaluation-slider, .mt-score-slider, .ui-slider-handle', function(e) {
                var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];
                $(this).trigger('mousedown', touch);
            }, 'admin_touch');
        } else {
            // Fallback with namespaced events
            $(document).on('touchstart.mt_admin', '.mt-evaluation-slider, .mt-score-slider, .ui-slider-handle', function(e) {
                var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];
                $(this).trigger('mousedown', touch);
            });
        }
        // Improve touch targets for mobile
        $('.mt-evaluation-slider, .mt-score-slider').css({
            'min-height': '44px',
            'touch-action': 'pan-y'
        });
        // Add mobile-friendly class to body for CSS targeting
        $('body').addClass('mt-touch-enabled');
    });
}
// Ensure mt_admin object exists with fallback values
if (typeof mt_admin === 'undefined') {
    // mt_admin object not found, creating fallback
    window.mt_admin = {
        ajax_url: ajaxurl || '/wp-admin/admin-ajax.php',
        nonce: $('#mt_admin_nonce').val() || '',
        admin_url: '/wp-admin/',
        i18n: {
            confirm_remove_assignment: 'Are you sure you want to remove this assignment?',
            assignment_removed: 'Assignment removed successfully.',
            error_occurred: 'An error occurred. Please try again.',
            no_assignments: 'No assignments yet',
            processing: 'Processing...',
            select_jury_and_candidates: 'Please select a jury member and at least one candidate.',
            assignments_created: 'Assignments created successfully.',
            assign_selected: 'Assign Selected',
            confirm_clear_all: 'Are you sure you want to clear ALL assignments? This cannot be undone.',
            confirm_clear_all_second: 'This will remove ALL jury assignments. Are you absolutely sure?',
            clearing: 'Clearing...',
            clear_all: 'Clear All',
            all_assignments_cleared: 'All assignments have been cleared.',
            export_started: 'Export started. Download will begin shortly.'
        }
    };
}
// Ensure i18n object exists
if (typeof mt_admin.i18n === 'undefined') {
    mt_admin.i18n = {
        confirm_remove_assignment: 'Are you sure you want to remove this assignment?',
        assignment_removed: 'Assignment removed successfully.',
        error_occurred: 'An error occurred. Please try again.',
        no_assignments: 'No assignments yet',
        processing: 'Processing...',
        select_jury_and_candidates: 'Please select a jury member and at least one candidate.',
        assignments_created: 'Assignments created successfully.',
        assign_selected: 'Assign Selected',
        confirm_clear_all: 'Are you sure you want to clear ALL assignments? This cannot be undone.',
        confirm_clear_all_second: 'This will remove ALL jury assignments. Are you absolutely sure?',
        clearing: 'Clearing...',
        clear_all: 'Clear All',
        all_assignments_cleared: 'All assignments have been cleared.',
        export_started: 'Export started. Download will begin shortly.'
    };
}
(function($) {
    'use strict';
    // General utility functions that can run on any admin page
    function initTooltips() {
        if (typeof $.fn.tooltip === 'function') {
            $('.mt-tooltip').tooltip();
        }
    }
    function initTabs() { /* ... tab logic ... */ }
    function initModals() { /* ... modal logic ... */ }
    function initConfirmations() { /* ... confirmation logic ... */ }
    function initAjaxForms() { /* ... ajax form logic ... */ }
    function initMediaUpload() { /* ... media upload logic ... */ }
    /**
     * Show notification message to user
     * @param {string} message - The message to display
     * @param {string} type - Type of notification ('success', 'error', 'warning', 'info')
     */
    window.mtShowNotification = function(message, type) {
        type = type || 'info';
        // Remove any existing notifications
        $('.mt-notification').remove();
        // Map types to WordPress notice classes
        const typeMap = {
            'success': 'notice-success',
            'error': 'notice-error',
            'warning': 'notice-warning',
            'info': 'notice-info'
        };
        const noticeClass = typeMap[type] || 'notice-info';
        // Create notification HTML
        const notificationHtml = `
            <div class="mt-notification notice ${noticeClass} is-dismissible">
                <p>${message}</p>
                <button type="button" class="notice-dismiss">
                    <span class="screen-reader-text">Dismiss this notice.</span>
                </button>
            </div>
        `;
        // Add notification after the page title
        const $target = $('.wrap h1').first();
        if ($target.length) {
            $(notificationHtml).insertAfter($target);
        } else {
            // Fallback: add to beginning of .wrap
            $('.wrap').prepend(notificationHtml);
        }
        // Auto-dismiss after 5 seconds for success messages
        if (type === 'success') {
            setTimeout(function() {
                $('.mt-notification').fadeOut(400, function() {
                    $(this).remove();
                });
            }, 5000);
        }
        // Handle dismiss button with namespaced event
        $(document).on('click.mt_admin', '.mt-notification .notice-dismiss', function() {
            $(this).closest('.mt-notification').fadeOut(400, function() {
                $(this).remove();
            });
        });
    };
    /**
     * Button loading state management
     * @param {jQuery} $button - Button element
     * @param {boolean} loading - True to show loading, false to hide
     * @param {string} originalText - Original button text to restore
     * @since 2.2.28
     */
    window.setButtonLoading = function($button, loading, originalText) {
        if (loading) {
            $button.addClass('loading').prop('disabled', true);
            if (originalText) {
                $button.data('original-text', originalText);
            }
        } else {
            $button.removeClass('loading').prop('disabled', false);
            const text = $button.data('original-text');
            if (text) {
                $button.text(text);
            }
        }
    };
    /**
     * Add loading overlay to element
     * @param {jQuery} $element - Element to overlay
     * @param {boolean} show - True to show, false to hide
     * @since 2.2.28
     */
    window.setLoadingOverlay = function($element, show) {
        if (show) {
            $element.addClass('mt-loading-overlay active');
        } else {
            $element.removeClass('active');
        }
    };
    /**
     * Refresh dashboard widget
     * @param {string} widgetId - The ID of the widget to refresh
     * @param {function} callback - Optional callback after refresh
     * @since 2.2.28
     */
    window.refreshDashboardWidget = function(widgetId, callback) {
        const $widget = $('#' + widgetId);
        if (!$widget.length) {
            if (callback) callback(false);
            return;
        }
        // Add loading state
        $widget.addClass('mt-widget-loading');
        $.ajax({
            url: mt_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'mt_refresh_widget',
                widget: widgetId,
                nonce: mt_admin.nonce
            },
            success: function(response) {
                if (response.success && response.data && response.data.html) {
                    $widget.html(response.data.html);
                    // Reinitialize any dynamic elements in the widget
                    if (typeof initTooltips === 'function') {
                        initTooltips();
                    }
                    if (callback) callback(true);
                } else {
                    if (callback) callback(false);
                }
            },
            error: function() {
                if (callback) callback(false);
            },
            complete: function() {
                $widget.removeClass('mt-widget-loading');
            }
        });
    };
    /**
     * Refresh multiple widgets
     * @param {array} widgetIds - Array of widget IDs to refresh
     * @since 2.2.28
     */
    window.refreshDashboardWidgets = function(widgetIds) {
        if (!Array.isArray(widgetIds)) {
            widgetIds = [widgetIds];
        }
        widgetIds.forEach(function(widgetId) {
            refreshDashboardWidget(widgetId);
        });
    };
    /**
     * Manager object for the "Assignment Management" page.
     * Contains all logic specific to this page.
     */
    const MTAssignmentManager = {
        init: function() {
            // This method is the entry point for all assignment page functionality.
            // MTAssignmentManager initialized
            this.bindEvents();
            this.initBulkActions();
        },
        bindEvents: function() {
            // Auto-assign button
            $(document).on('click', '#mt-auto-assign-btn', (e) => {
                e.preventDefault();
                this.showAutoAssignModal();
            });
            // Manual assignment button
            $(document).on('click', '#mt-manual-assign-btn', (e) => {
                e.preventDefault();
                this.showManualAssignModal();
            });
            // Bulk actions button
            $(document).on('click', '#mt-bulk-actions-btn', (e) => {
                e.preventDefault();
                this.toggleBulkActions();
            });
            // Export button
            $(document).on('click', '#mt-export-btn', (e) => {
                e.preventDefault();
                this.exportAssignments();
            });
            // Clear all button
            $(document).on('click', '#mt-clear-all-btn', (e) => {
                e.preventDefault();
                this.clearAllAssignments();
            });
            // Remove individual assignment
            $(document).on('click', '.mt-remove-assignment', (e) => {
                e.preventDefault();
                this.removeAssignment($(e.currentTarget));
            });
            // Modal close buttons
            $(document).on('click', '.mt-modal-close', (e) => {
                e.preventDefault();
                $('.mt-modal').fadeOut(300);
            });
            // Manual assignment form submission
            $(document).on('submit', '#mt-manual-assignment-form', (e) => {
                e.preventDefault();
                this.submitManualAssignment();
            });
            // Auto-assignment form submission
            $(document).on('submit', '#mt-auto-assign-modal form', (e) => {
                e.preventDefault();
                this.submitAutoAssignment();
            });
            // Filter handlers
            $(document).on('change', '#mt-filter-jury, #mt-filter-status', () => {
                this.applyFilters();
            });
            // Search handler
            $(document).on('keyup', '#mt-assignment-search', function() {
                const searchTerm = $(this).val();
                MTAssignmentManager.filterAssignments(searchTerm);
            });
        },
        initBulkActions: function() {
            // Select all checkbox
            $(document).on('change', '#mt-select-all-assignments', function() {
                $('.mt-assignment-checkbox').prop('checked', $(this).prop('checked'));
            });
            // Apply bulk action button
            $(document).on('click', '#mt-apply-bulk-action', (e) => {
                e.preventDefault();
                this.applyBulkAction();
            });
            // Cancel bulk action button
            $(document).on('click', '#mt-cancel-bulk-action', (e) => {
                e.preventDefault();
                this.toggleBulkActions();
            });
        },
        showAutoAssignModal: function() {
            $('#mt-auto-assign-modal').fadeIn(300);
        },
        showManualAssignModal: function() {
            $('#mt-manual-assign-modal').fadeIn(300);
        },
        submitAutoAssignment: function() {
            const method = $('#assignment_method').val();
            const candidatesPerJury = $('#candidates_per_jury').val();
            const clearExisting = $('#clear_existing').is(':checked') ? 'true' : 'false';
            $.ajax({
                url: mt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mt_auto_assign',
                    nonce: mt_admin.nonce,
                    method: method,
                    candidates_per_jury: candidatesPerJury,
                    clear_existing: clearExisting
                },
                beforeSend: () => {
                    $('#mt-auto-assign-modal button[type="submit"]').prop('disabled', true).text(mt_admin.i18n.processing || 'Processing...');
                },
                success: (response) => {
                    if (response.success) {
                        mtShowNotification(response.data.message || mt_admin.i18n.assignments_created, 'success');
                        $('#mt-auto-assign-modal').fadeOut(300);
                        // Add small delay to show success message before reload
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        mtShowNotification(response.data || mt_admin.i18n.error_occurred, 'error');
                    }
                },
                error: () => {
                    mtShowNotification(mt_admin.i18n.error_occurred, 'error');
                },
                complete: () => {
                    $('#mt-auto-assign-modal button[type="submit"]').prop('disabled', false).text('Run Auto-Assignment');
                }
            });
        },
        submitManualAssignment: function() {
            const juryMemberId = $('#manual_jury_member').val();
            const candidateIds = [];
            $('input[name="candidate_ids[]"]:checked').each(function() {
                candidateIds.push($(this).val());
            });
            if (!juryMemberId || candidateIds.length === 0) {
                mtShowNotification(mt_admin.i18n.select_jury_and_candidates, 'warning');
                return;
            }
            $.ajax({
                url: mt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mt_manual_assign',
                    nonce: mt_admin.nonce,
                    jury_member_id: juryMemberId,
                    candidate_ids: candidateIds
                },
                beforeSend: () => {
                    $('#mt-manual-assignment-form button[type="submit"]').prop('disabled', true).text(mt_admin.i18n.processing || 'Processing...');
                },
                success: (response) => {
                    if (response.success) {
                        mtShowNotification(response.data.message || mt_admin.i18n.assignments_created, 'success');
                        $('#mt-manual-assign-modal').fadeOut(300);
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        mtShowNotification(response.data || mt_admin.i18n.error_occurred, 'error');
                    }
                },
                error: () => {
                    mtShowNotification(mt_admin.i18n.error_occurred, 'error');
                },
                complete: () => {
                    $('#mt-manual-assignment-form button[type="submit"]').prop('disabled', false).text(mt_admin.i18n.assign_selected);
                }
            });
        },
        removeAssignment: function($button) {
            const assignmentId = $button.data('assignment-id');
            const juryName = $button.data('jury');
            const candidateName = $button.data('candidate');
            if (!confirm(mt_admin.i18n.confirm_remove_assignment)) {
                return;
            }
            $.ajax({
                url: mt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mt_remove_assignment',
                    nonce: mt_admin.nonce,
                    assignment_id: assignmentId
                },
                beforeSend: () => {
                    $button.prop('disabled', true).text(mt_admin.i18n.processing || 'Processing...');
                },
                success: (response) => {
                    if (response.success) {
                        $button.closest('tr').fadeOut(400, function() {
                            $(this).remove();
                            // Check if table is empty
                            if ($('.mt-assignments-table tbody tr').length === 0) {
                                $('.mt-assignments-table tbody').html('<tr><td colspan="8" class="no-items">' + mt_admin.i18n.no_assignments + '</td></tr>');
                            }
                        });
                        mtShowNotification(mt_admin.i18n.assignment_removed, 'success');
                    } else {
                        mtShowNotification(response.data || mt_admin.i18n.error_occurred, 'error');
                    }
                },
                error: () => {
                    mtShowNotification(mt_admin.i18n.error_occurred, 'error');
                },
                complete: () => {
                    $button.prop('disabled', false).text(mt_admin && mt_admin.i18n && mt_admin.i18n.remove ? mt_admin.i18n.remove : 'Entfernen');
                }
            });
        },
        clearAllAssignments: function() {
            if (!confirm(mt_admin.i18n.confirm_clear_all)) {
                return;
            }
            if (!confirm(mt_admin.i18n.confirm_clear_all_second)) {
                return;
            }
            $.ajax({
                url: mt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mt_clear_all_assignments',
                    nonce: mt_admin.nonce
                },
                beforeSend: () => {
                    $('#mt-clear-all-btn').prop('disabled', true).text(mt_admin.i18n.clearing || 'Clearing...');
                },
                success: (response) => {
                    if (response.success) {
                        mtShowNotification(mt_admin.i18n.all_assignments_cleared, 'success');
                        location.reload();
                    } else {
                        mtShowNotification(response.data || mt_admin.i18n.error_occurred, 'error');
                    }
                },
                error: () => {
                    mtShowNotification(mt_admin.i18n.error_occurred, 'error');
                },
                complete: () => {
                    $('#mt-clear-all-btn').prop('disabled', false).html('<span class="dashicons dashicons-trash"></span> ' + mt_admin.i18n.clear_all);
                }
            });
        },
        exportAssignments: function() {
            // Create a form to trigger download
            const form = $('<form/>', {
                action: mt_admin.ajax_url,
                method: 'POST'
            });
            form.append($('<input/>', {
                type: 'hidden',
                name: 'action',
                value: 'mt_export_assignments'
            }));
            form.append($('<input/>', {
                type: 'hidden',
                name: 'nonce',
                value: mt_admin.nonce
            }));
            form.appendTo('body').submit().remove();
            mtShowNotification(mt_admin.i18n.export_started, 'info');
        },
        toggleBulkActions: function() {
            const $container = $('#mt-bulk-actions-container');
            const $checkboxColumn = $('.check-column');
            if ($container.is(':visible')) {
                $container.slideUp();
                $checkboxColumn.hide();
                $('.mt-assignment-checkbox').prop('checked', false);
                $('#mt-select-all-assignments').prop('checked', false);
            } else {
                $container.slideDown();
                $checkboxColumn.show();
            }
        },
        applyBulkAction: function() {
            const action = $('#mt-bulk-action-select').val();
            const selectedIds = [];
            $('.mt-assignment-checkbox:checked').each(function() {
                selectedIds.push($(this).val());
            });
            if (!action) {
                mtShowNotification(mt_admin.i18n.select_bulk_action || 'Please select a bulk action', 'warning');
                return;
            }
            if (selectedIds.length === 0) {
                mtShowNotification(mt_admin.i18n.select_assignments || 'Please select at least one assignment', 'warning');
                return;
            }
            if (action === 'remove') {
                this.bulkRemoveAssignments(selectedIds);
            } else if (action === 'export') {
                this.bulkExportAssignments(selectedIds);
            } else if (action === 'reassign') {
                this.showReassignModal(selectedIds);
            }
        },
        bulkRemoveAssignments: function(assignmentIds) {
            if (!confirm('Are you sure you want to remove the selected assignments?')) {
                return;
            }
            $.ajax({
                url: mt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mt_bulk_remove_assignments',
                    nonce: mt_admin.nonce,
                    assignment_ids: assignmentIds
                },
                beforeSend: () => {
                    $('#mt-apply-bulk-action').prop('disabled', true).text('Processing...');
                },
                success: (response) => {
                    if (response.success) {
                        mtShowNotification(response.data.message || 'Assignments removed successfully', 'success');
                        location.reload();
                    } else {
                        mtShowNotification(response.data || 'An error occurred', 'error');
                    }
                },
                error: () => {
                    mtShowNotification('An error occurred', 'error');
                },
                complete: () => {
                    $('#mt-apply-bulk-action').prop('disabled', false).text('Apply');
                }
            });
        },
        bulkExportAssignments: function(assignmentIds) {
            const form = $('<form/>', {
                action: mt_admin.ajax_url,
                method: 'POST'
            });
            form.append($('<input/>', {
                type: 'hidden',
                name: 'action',
                value: 'mt_export_assignments'
            }));
            form.append($('<input/>', {
                type: 'hidden',
                name: 'nonce',
                value: mt_admin.nonce
            }));
            assignmentIds.forEach(id => {
                form.append($('<input/>', {
                    type: 'hidden',
                    name: 'assignment_ids[]',
                    value: id
                }));
            });
            form.appendTo('body').submit().remove();
        },
        filterAssignments: function(searchTerm) {
            const rows = $('.mt-assignments-table tbody tr');
            if (!searchTerm) {
                rows.show();
                return;
            }
            const term = searchTerm.toLowerCase();
            rows.each(function() {
                const text = $(this).text().toLowerCase();
                if (text.includes(term)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        },
        applyFilters: function() {
            const juryFilter = $('#mt-filter-jury').val();
            const statusFilter = $('#mt-filter-status').val();
            const rows = $('.mt-assignments-table tbody tr');
            rows.each(function() {
                let show = true;
                const $row = $(this);
                if (juryFilter) {
                    const juryId = $row.find('.mt-assignment-checkbox').data('jury-id');
                    if (juryId != juryFilter) {
                        show = false;
                    }
                }
                if (statusFilter && show) {
                    const status = $row.find('.mt-status').text().toLowerCase();
                    if (status !== statusFilter) {
                        show = false;
                    }
                }
                if (show) {
                    $row.show();
                } else {
                    $row.hide();
                }
            });
        },
        showReassignModal: function(assignmentIds) {
            // Store the assignment IDs for later use
            this.pendingReassignments = assignmentIds;
            // Check if modal exists, if not create it
            if ($('#mt-reassign-modal').length === 0) {
                this.createReassignModal();
            }
            // Show the modal
            $('#mt-reassign-modal').fadeIn(300);
        },
        createReassignModal: function() {
            // Get jury members from the filter dropdown as a quick solution
            const juryOptions = $('#mt-filter-jury option').clone();
            const modalHtml = `
                <div id="mt-reassign-modal" class="mt-modal" style="display: none;">
                    <div class="mt-modal-content">
                        <h2>${mt_admin.i18n.reassign_assignments || 'Reassign Assignments'}</h2>
                        <p>${mt_admin.i18n.reassign_description || 'Select a new jury member to reassign the selected assignments to:'}</p>
                        <form id="mt-reassign-form">
                            <div class="mt-form-group">
                                <label for="reassign_jury_member">${mt_admin.i18n.new_jury_member || 'New Jury Member'}</label>
                                <select name="new_jury_member_id" id="reassign_jury_member" class="widefat" required>
                                    <option value="">${mt_admin.i18n.select_jury_member || 'Select Jury Member'}</option>
                                </select>
                            </div>
                            <div class="mt-modal-actions">
                                <button type="submit" class="button button-primary">${mt_admin.i18n.reassign || 'Reassign'}</button>
                                <button type="button" class="button mt-modal-close">${mt_admin.i18n.cancel || 'Cancel'}</button>
                            </div>
                        </form>
                    </div>
                </div>
            `;
            // Append modal to body
            $('body').append(modalHtml);
            // Populate jury options
            $('#reassign_jury_member').html(juryOptions);
            // Bind close event
            $(document).on('click', '#mt-reassign-modal .mt-modal-close', (e) => {
                e.preventDefault();
                $('#mt-reassign-modal').fadeOut(300);
            });
            // Bind form submit
            $(document).on('submit', '#mt-reassign-form', (e) => {
                e.preventDefault();
                this.submitReassignment();
            });
        },
        submitReassignment: function() {
            const newJuryMemberId = $('#reassign_jury_member').val();
            if (!newJuryMemberId) {
                mtShowNotification(mt_admin.i18n.select_jury_member || 'Please select a jury member', 'warning');
                return;
            }
            if (!this.pendingReassignments || this.pendingReassignments.length === 0) {
                mtShowNotification(mt_admin.i18n.no_assignments_selected || 'No assignments selected', 'warning');
                return;
            }
            $.ajax({
                url: mt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mt_bulk_reassign_assignments',
                    nonce: mt_admin.nonce,
                    assignment_ids: this.pendingReassignments,
                    new_jury_member_id: newJuryMemberId
                },
                beforeSend: () => {
                    $('#mt-reassign-form button[type="submit"]').prop('disabled', true).text(mt_admin.i18n.processing || 'Processing...');
                },
                success: (response) => {
                    if (response.success) {
                        mtShowNotification(response.data.message || 'Assignments reassigned successfully', 'success');
                        $('#mt-reassign-modal').fadeOut(300);
                        location.reload();
                    } else {
                        mtShowNotification(response.data || 'An error occurred', 'error');
                    }
                },
                error: () => {
                    mtShowNotification(mt_admin.i18n.error_occurred || 'An error occurred', 'error');
                },
                complete: () => {
                    $('#mt-reassign-form button[type="submit"]').prop('disabled', false).text(mt_admin.i18n.reassign || 'Reassign');
                }
            });
        }
    };
    /**
     * Manager object for the "Evaluations" admin page.
     * Contains all logic specific to this page.
     */
    window.MTEvaluationManager = {
        init: function() {
            // Entry point for all evaluation page functionality.
            // MTEvaluationManager initialized
            this.bindEvents();
        },
        /**
         * Get confirmation message based on the action type
         * Provides more specific and helpful messages for different actions
         */
        getConfirmMessage: function(action) {
            const messages = {
                'delete': mt_admin.i18n.confirm_delete_evaluations || 'Are you sure you want to permanently delete the selected evaluations? This cannot be undone.',
                'approve': mt_admin.i18n.confirm_approve_evaluations || 'Are you sure you want to approve the selected evaluations?',
                'reject': mt_admin.i18n.confirm_reject_evaluations || 'Are you sure you want to reject the selected evaluations?',
                'reset': mt_admin.i18n.confirm_reset_evaluations || 'Are you sure you want to reset the selected evaluations to draft status?',
                'export': mt_admin.i18n.confirm_export_evaluations || 'Are you sure you want to export the selected evaluations?'
            };
            // Return specific message or default
            return messages[action] || 'Are you sure you want to ' + action + ' the selected evaluations?';
        },
        bindEvents: function() {
            // Bind all event listeners for the evaluations page.
            $(document).on('click', '.view-details', (e) => {
                const $trigger = $(e.currentTarget);
                const evaluationId = $trigger.data('evaluation-id');
                this.viewDetails(evaluationId, $trigger);
            });
            $(document).on('click', '#cb-select-all-1, #cb-select-all-2', this.handleSelectAll);
            $('input[name="evaluation[]"]').on('click', this.handleSingleSelect);
            $(document).on('click', '#doaction, #doaction2', (e) => {
                const action = $(e.currentTarget).prev('select').val();
                this.applyBulkAction(action);
            });
        },
        viewDetails: function(evaluationId, $trigger) {
            // Show loading state
            const $modal = this.createModal();
            $modal.data('trigger', $trigger); // Store trigger for focus return
            $modal.find('.mt-modal-body').html('<div class="mt-loading">Loading evaluation details...</div>');
            $modal.fadeIn(300, function() {
                // Focus on modal body for screen readers
                $modal.find('.mt-modal-body').focus();
            });
            // Fetch evaluation details via AJAX
            $.ajax({
                url: mt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mt_get_evaluation_details',
                    nonce: mt_admin.nonce,
                    evaluation_id: evaluationId
                },
                success: (response) => {
                    if (response.success) {
                        const html = this.renderEvaluationDetails(response.data);
                        $modal.find('.mt-modal-body').html(html);
                    } else {
                        $modal.find('.mt-modal-body').html(
                            '<div class="notice notice-error"><p>' + 
                            (response.data?.message || 'Failed to load evaluation details') + 
                            '</p></div>'
                        );
                    }
                },
                error: () => {
                    $modal.find('.mt-modal-body').html(
                        '<div class="notice notice-error"><p>An error occurred while loading evaluation details</p></div>'
                    );
                }
            });
        },
        createModal: function() {
            // Check if modal already exists
            let $modal = $('#mt-evaluation-modal');
            if ($modal.length === 0) {
                // Create modal HTML with accessibility attributes
                const modalHtml = `
                    <div id="mt-evaluation-modal" class="mt-modal" role="dialog" aria-modal="true" aria-labelledby="mt-modal-title" style="display:none;">
                        <div class="mt-modal-overlay" aria-hidden="true"></div>
                        <div class="mt-modal-content">
                            <div class="mt-modal-header">
                                <h2 id="mt-modal-title">Evaluation Details</h2>
                                <button class="mt-modal-close" aria-label="Close dialog" type="button">&times;</button>
                            </div>
                            <div class="mt-modal-body" tabindex="0"></div>
                        </div>
                    </div>
                `;
                $('body').append(modalHtml);
                $modal = $('#mt-evaluation-modal');
                // Bind close events
                $modal.find('.mt-modal-close, .mt-modal-overlay').on('click', () => {
                    this.closeModal($modal);
                });
                // Close on ESC key
                $(document).on('keydown', (e) => {
                    if (e.key === 'Escape' && $modal.is(':visible')) {
                        this.closeModal($modal);
                    }
                });
            }
            return $modal;
        },
        closeModal: function($modal) {
            $modal.fadeOut(300, function() {
                // Return focus to triggering element if stored
                if ($modal.data('trigger')) {
                    $modal.data('trigger').focus();
                }
            });
        },
        renderEvaluationDetails: function(data) {
            let scoresHtml = '';
            for (const [key, score] of Object.entries(data.scores)) {
                scoresHtml += `
                    <div class="mt-score-item">
                        <label>${score.label}:</label>
                        <span class="mt-score-value">${score.value}/10</span>
                        <div class="mt-score-bar">
                            <div class="mt-score-fill" style="width: ${score.value * 10}%"></div>
                        </div>
                    </div>
                `;
            }
            return `
                <div class="mt-evaluation-details">
                    <div class="mt-detail-section">
                        <h3>Basic Information</h3>
                        <table class="mt-detail-table">
                            <tr>
                                <th>Jury Member:</th>
                                <td>${data.jury_member}</td>
                            </tr>
                            <tr>
                                <th>Candidate:</th>
                                <td>${data.candidate}</td>
                            </tr>
                            <tr>
                                <th>Organization:</th>
                                <td>${data.organization || '-'}</td>
                            </tr>
                            <tr>
                                <th>Categories:</th>
                                <td>${data.categories || '-'}</td>
                            </tr>
                            <tr>
                                <th>Status:</th>
                                <td><span class="mt-status mt-status-${data.status}">${data.status}</span></td>
                            </tr>
                        </table>
                    </div>
                    <div class="mt-detail-section">
                        <h3>Scores</h3>
                        ${scoresHtml}
                        <div class="mt-score-summary">
                            <strong>${mt_evaluations_i18n.total_score_label || 'Total Score:'}</strong> ${data.total_score.toFixed(1)}/50
                            <br>
                            <strong>${mt_evaluations_i18n.average_score_label || 'Average Score:'}</strong> ${data.average_score.toFixed(1)}/10
                        </div>
                    </div>
                    ${data.comments ? `
                        <div class="mt-detail-section">
                            <h3>Comments</h3>
                            <div class="mt-comments">${data.comments}</div>
                        </div>
                    ` : ''}
                    <div class="mt-detail-section mt-timestamps">
                        <small>
                            Created: ${data.created_at}<br>
                            Last Updated: ${data.updated_at}
                        </small>
                    </div>
                </div>
            `;
        },
        handleSelectAll: function() {
            const isChecked = $(this).prop('checked');
            $('input[name="evaluation[]"]').prop('checked', isChecked);
            $('#cb-select-all-1, #cb-select-all-2').prop('checked', isChecked);
        },
        handleSingleSelect: function() {
            const allChecked = $('input[name="evaluation[]"]').length === $('input[name="evaluation[]"]:checked').length;
            $('#cb-select-all-1, #cb-select-all-2').prop('checked', allChecked);
        },
        applyBulkAction: function(action) {
            if (action === '-1') {
                mtShowNotification(mt_admin.i18n.select_bulk_action || 'Please select a bulk action', 'warning');
                return;
            }
            const selected = [];
            $('input[name="evaluation[]"]:checked').each(function() {
                selected.push($(this).val());
            });
            if (selected.length === 0) {
                mtShowNotification(mt_admin.i18n.select_assignments || 'Please select at least one evaluation', 'warning');
                return;
            }
            // Use the improved confirmation message function
            const confirmMessage = this.getConfirmMessage(action);
            if (!confirm(confirmMessage)) {
                return;
            }
            // Perform bulk action via AJAX with improved loading indicators
            this.performBulkAction(action, selected);
        },
        /**
         * Perform the bulk action with proper loading indicators and error handling
         */
        performBulkAction: function(action, evaluationIds) {
            // Store original button text
            const $buttons = $('#doaction, #doaction2');
            const originalText = $buttons.first().val();
            // Show loading spinner if available
            const $spinner = $('.spinner');
            if ($spinner.length) {
                $spinner.addClass('is-active');
            }
            $.ajax({
                url: mt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mt_bulk_evaluation_action',
                    bulk_action: action,
                    evaluation_ids: evaluationIds,
                    nonce: mt_admin.nonce
                },
                beforeSend: function() {
                    // Disable buttons and show processing text
                    $buttons.prop('disabled', true).val(mt_admin.i18n.processing || 'Processing...');
                    // Add visual feedback to selected rows
                    $('input[name="evaluation[]"]:checked').closest('tr').addClass('processing').css('opacity', '0.6');
                },
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        mtShowNotification(response.data.message || 'Bulk action completed successfully', 'success');
                        // Reload page after a short delay to show the message
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        // Show error message
                        mtShowNotification(response.data || 'An error occurred', 'error');
                        // Remove processing state from rows
                        $('input[name="evaluation[]"]:checked').closest('tr').removeClass('processing').css('opacity', '1');
                    }
                },
                error: function(xhr, status, error) {
                    // Show detailed error message
                    const errorMsg = mt_admin.i18n.error_occurred || 'An error occurred. Please try again.';
                    mtShowNotification(errorMsg + ' (' + error + ')', 'error');
                    // Remove processing state from rows
                    $('input[name="evaluation[]"]:checked').closest('tr').removeClass('processing').css('opacity', '1');
                },
                complete: function() {
                    // Re-enable buttons and restore original text
                    $buttons.prop('disabled', false).val(originalText || 'Apply');
                    // Hide loading spinner
                    if ($spinner.length) {
                        $spinner.removeClass('is-active');
                    }
                }
            });
        }
    };
    /**
     * Main Initialization Logic
     * This runs on every admin page load.
     */
    $(document).ready(function() {
        // Mobility Trailblazers Admin JS Loaded
        // Initialize general scripts that run on all pages
        initTooltips();
        initTabs();
        initModals();
        initConfirmations();
        initAjaxForms();
        initMediaUpload();
        if ($.fn.select2) {
            $('.mt-select2').select2();
        }
        if ($.fn.datepicker) {
            $('.mt-datepicker').datepicker({ dateFormat: 'yy-mm-dd' });
        }
        // --- Conditional Initialization for Page-Specific Managers ---
        // Check for the Assignment Management page
        if ($('#mt-auto-assign-btn').length > 0 || $('.mt-assignments-table').length > 0) {
            MTAssignmentManager.init();
        }
        // Check for the Evaluations page using body class (more reliable than checking page title)
        if ($('body').hasClass('mobility-trailblazers_page_mt-evaluations')) {
             window.MTEvaluationManager.init();
        }
    });
})(jQuery);
